use electric_prod_bc
select pp.PolicyNumber, m.beforeSendlocktime,m.ErrorDescription,m.EventName ,SendOrder from bc_message m
join bc_Policyperiod pp on m.EventRootKey ='PolicyPeriod:'+Cast(pp.id as varchar)
where destinationiD=100 and status=4  order by  pp.Policynumber
