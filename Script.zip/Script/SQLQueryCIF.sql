--use electric_prod_bc; select count(*) from bcx_cifrecorddata_ext with (nolock)
---select * from bc_processhistory with (nolock) where ProcessType in(10007) order by CreationDate desc

select * from bcx_tempUnitOfWork   ---CIFDataRemover
select * from bcx_cifworkqueue_ext  ---CIFWorkQueue 
select * from bcx_CIFRecordData_Ext  ---CIFFile
